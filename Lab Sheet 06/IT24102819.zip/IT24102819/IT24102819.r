getwd()
setwd("C:\\Users\\pamid\\OneDrive\\Desktop\\IT24102819")

#X = Number of students who passed the test out of 50 students
#n=50
#p=0.85

#What is the distribution of X?
#Binomial Distribution

pbinom(46,50,0.85,lower.tail = FALSE)


#X = Number of calls received per hour
#lambda = 12(12 calls per hours)

#What is the distribution of X?
#Poisson Distribution

ppois(15,12)
