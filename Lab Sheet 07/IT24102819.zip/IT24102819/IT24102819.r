getwd()
setwd("C:\\Users\\pamid\\OneDrive\\Desktop\\IT24102819")

# X =  X represent the number of minutes the train arrives after 8:00 a.m.
# 10<X<25 = X<=25-X<=10
punif(25,min = 0,max = 40,lower.tail = TRUE) - punif(10,min = 0,max = 40,lower.tail = TRUE)

#λ = 1/3 = 0.33
#X<=2
pexp(2,rate = 0.3,lower.tail = TRUE)

#X>130
pnorm(130,mean = 100,sd=15,lower.tail = FALSE)

#95 th percantile
qnorm(0.95,mean = 100,sd=15)