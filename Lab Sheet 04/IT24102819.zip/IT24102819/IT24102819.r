setwd("C:\\Users\\it24102819\\Desktop\\IT24102819")

#import data
branch_data <- read.table("Exercise.txt", header = TRUE,sep = ",")

str(branch_data)

boxplot(branch_data$Sales_X1,main = "Boxplot of Sales",ylab = "Sales")

summary(branch_data)

outliers_In_Years <- function(x){
  Q1<- quantile(x)[2]
  Q3<- quantile(x)[4]
  IQR<- Q3-Q1
  
  Upper_Bound <- Q3 + 1.5 * IQR
  Lower_Bound <- Q1 - 1.5 * IQR
  
  print(paste("Upper Bound =", Upper_Bound))
  print(paste("Lower Bound =", Lower_Bound))
  print(paste("Outliers in Years =", paste(sort(x[x<Lower_Bound | x>Upper_Bound]), collapse = ",")))
}

outliers_In_Years(branch_data$Years_X3)